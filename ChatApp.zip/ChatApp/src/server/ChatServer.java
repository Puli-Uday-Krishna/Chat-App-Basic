package src.server;

import javax.net.ssl.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class ChatServer {

    public static void main(String[] args) throws Exception {
        // Set up keystore and SSL configuration
        System.setProperty("javax.net.ssl.keyStore", "resources/keystore.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "changeit");

        // Create SSLContext
        SSLContext sslContext = SSLContext.getInstance("TLS");
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        KeyStore keystore = KeyStore.getInstance("JKS");
        FileInputStream fis = new FileInputStream("resources/keystore.jks");
        keystore.load(fis, "changeit".toCharArray());

        kmf.init(keystore, "changeit".toCharArray());
        sslContext.init(kmf.getKeyManagers(), null, new SecureRandom());

        // Start SSL server socket on port 8443
        SSLServerSocketFactory factory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        SSLServerSocket serverSocket = (SSLServerSocket) factory.createServerSocket(8443);
        serverSocket.setEnabledProtocols(new String[]{"TLSv1.2", "TLSv1.3"});
        serverSocket.setEnabledCipherSuites(new String[]{
            "TLS_AES_128_GCM_SHA256", 
            "TLS_AES_256_GCM_SHA384"
        });
        System.out.println("Server started on port 8443.");

        // Accept connections
        while (true) {
            SSLSocket socket = (SSLSocket) serverSocket.accept();
            // Handle each client in a separate thread
            new ClientHandler(socket).start();
        }
    }
}

class ClientHandler extends Thread {
    private SSLSocket socket;

    public ClientHandler(SSLSocket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            String clientIP = socket.getInetAddress().getHostAddress();
            String message;
            while ((message = in.readLine()) != null) {
                System.out.println("Received: " + message);
                out.println("Echo: " + message); // Echo message back to client
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class EncryptionUtil {
    public static SecretKey generateKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256); // Use 256-bit AES
        return keyGen.generateKey();
    }

    public static byte[] encrypt(String message, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(message.getBytes());
    }

    public static String decrypt(byte[] encryptedMessage, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        return new String(cipher.doFinal(encryptedMessage));
    }
}

class RateLimiter {
    private static final int MAX_REQUESTS = 10;
    private static final long TIME_WINDOW = 60000; // 1 minute
    private final ConcurrentHashMap<String, AtomicInteger> requestCounts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> timestamps = new ConcurrentHashMap<>();

    public synchronized boolean isAllowed(String clientIP) {
        long currentTime = System.currentTimeMillis();
        requestCounts.putIfAbsent(clientIP, new AtomicInteger(0));
        timestamps.putIfAbsent(clientIP, currentTime);

        if (currentTime - timestamps.get(clientIP) > TIME_WINDOW) {
            requestCounts.get(clientIP).set(0);
            timestamps.put(clientIP, currentTime);
        }

        if (requestCounts.get(clientIP).incrementAndGet() > MAX_REQUESTS) {
            System.out.println("Client " + clientIP + " exceeded rate limit.");
            return false; // Block the client
        }
        return true;
    }
}
