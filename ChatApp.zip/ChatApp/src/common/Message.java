package src.common;

public class Message {
    
}
