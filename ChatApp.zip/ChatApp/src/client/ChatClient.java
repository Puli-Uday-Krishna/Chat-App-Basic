package src.client;

import javax.net.ssl.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;

public class ChatClient {

    public static void main(String[] args) {
        try {
            // Set up truststore and SSL configuration
            System.setProperty("javax.net.ssl.trustStore", "resources/truststore.jks");
            System.setProperty("javax.net.ssl.trustStorePassword", "changeit");

            // Create SSLContext
            SSLContext sslContext = SSLContext.getInstance("TLS");
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            KeyStore truststore = KeyStore.getInstance("JKS");

            try (FileInputStream fis = new FileInputStream("resources/truststore.jks")) {
                truststore.load(fis, "changeit".toCharArray());
            } catch (FileNotFoundException e) {
                System.err.println("Truststore file not found: " + e.getMessage());
                e.printStackTrace();
                return;
            }

            tmf.init(truststore);
            sslContext.init(null, tmf.getTrustManagers(), new SecureRandom());

            // Connect to the server
            SSLSocketFactory factory = (SSLSocketFactory) sslContext.getSocketFactory();
            try (SSLSocket socket = (SSLSocket) factory.createSocket("localhost", 8443);
                 BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

                socket.setEnabledProtocols(new String[]{"TLSv1.2", "TLSv1.3"});

                String message;
                while ((message = userInput.readLine()) != null) {
                    out.println(message);
                    String serverReply = in.readLine();
                    if (serverReply == null) {
                        System.out.println("Server closed the connection.");
                        break;
                    }
                    System.out.println("Server reply: " + serverReply);
                }
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
