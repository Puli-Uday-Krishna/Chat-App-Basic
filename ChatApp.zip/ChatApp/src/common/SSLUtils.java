package src.common;

import java.io.FileInputStream;
import java.security.KeyStore;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.SSLContext;

public class SSLUtils {

    public static SSLContext createSSLContext(String keystorePath, String keystorePassword, String truststorePath, String truststorePassword) throws Exception {
        // Load keystore
        KeyStore keystore = KeyStore.getInstance("JKS");
        FileInputStream keystoreFis = new FileInputStream(keystorePath);
        keystore.load(keystoreFis, keystorePassword.toCharArray());

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keystore, keystorePassword.toCharArray());

        // Load truststore
        KeyStore truststore = KeyStore.getInstance("JKS");
        FileInputStream truststoreFis = new FileInputStream(truststorePath);
        truststore.load(truststoreFis, truststorePassword.toCharArray());

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(truststore);

        // Initialize SSL context
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

        return sslContext;
    }
}
